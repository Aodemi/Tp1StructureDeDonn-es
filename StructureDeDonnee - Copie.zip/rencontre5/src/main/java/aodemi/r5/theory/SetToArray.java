package aodemi.r5.theory;
import java.util.*;
public class SetToArray {

    public static void main(String[] args) {

        Set<Integer> set = new TreeSet<>();
        for(int i =1; i<6; i++){
            set.add(i);
        }

        // 1ère Façon
        Integer[] tableau1=  set.toArray(new Integer[0]);
        System.out.println(Arrays.toString(tableau1));


        // 2ème Façon
        Integer[] tableau2 = new Integer[set.size()];
        for (Integer i: set) {
            tableau2[i-1]= i;
        }
        System.out.println(Arrays.toString(tableau2));
    }
}
