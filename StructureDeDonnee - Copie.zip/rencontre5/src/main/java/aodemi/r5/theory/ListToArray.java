package aodemi.r5.theory;

import java.util.*;

public class ListToArray {
    public static void main(String[] args) {

        List<Integer> list = new ArrayList<>();
        for(int i =1; i<6; i++){
            list.add(i);
        }

        // 1ère Façon
        Integer[] tableau1=  list.toArray(new Integer[0]);
        System.out.println(Arrays.toString(tableau1));


        // 2ème Façon
        Integer[] tableau2 = new Integer[list.size()];
        for (Integer i: list) {
            tableau2[i-1]= i;
        }
        System.out.println(Arrays.toString(tableau2));
    }
}
