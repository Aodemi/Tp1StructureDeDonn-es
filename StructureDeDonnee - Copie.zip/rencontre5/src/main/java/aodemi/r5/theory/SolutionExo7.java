package aodemi.r5.theory;

import java.io.Serializable;
import java.util.*;

public class SolutionExo7 extends ParentExo7 implements InterfaceExo7 {
    public static void main(String [] args){
        extract();
    }

    public static void extract(){
        SolutionExo7 facon1 = new SolutionExo7();
        ParentExo7 facon2 = new SolutionExo7();
        Object facon3 = new SolutionExo7();

        InterfaceExo7 facon4 = new SolutionExo7();
        //Polymorphisme = Héritage à l'envers!!!
        //Object -> Parent -> SolutionExo7 (Héritage)
        //SolutionExo7 -> Parent -> Object (Polymorphisme)

        String [] tableau = {"A", "B", "C", "A", "B"};
        Set<String> tableauSet = new LinkedHashSet<>(Arrays.asList(tableau));
        System.out.println("Il y a " + (tableau.length - tableauSet.size()) + " doublons");
    }
}
