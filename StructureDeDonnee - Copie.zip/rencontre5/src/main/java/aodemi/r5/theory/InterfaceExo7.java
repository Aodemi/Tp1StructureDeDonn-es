package aodemi.r5.theory;

public interface InterfaceExo7 {
}
