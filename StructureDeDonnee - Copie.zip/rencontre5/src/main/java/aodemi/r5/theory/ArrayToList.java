package aodemi.r5.theory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
public class ArrayToList {

    public static void main(String[] args) {

        Integer[] tableau= {1, 2, 3};

        // 1ère Façon
        List<Integer> list= Arrays.asList(tableau);
        System.out.println(list);

        //2ème Façon
        Collection <Integer> list2= Arrays.asList(tableau);
        System.out.println(list2);

        //3ème Façon  ***
        List<Integer> list3 = new ArrayList<>();
        list3 = Arrays.asList(tableau);
        System.out.println(list3);

        // 4ème Façon
        ArrayList<Integer> list4 = new ArrayList<>();
        for(int i=0; i<tableau.length; i++){
            list4.add(tableau[i]);
        }
        System.out.println(list4);
    }
}
