package aodemi.r5.theory;

import lombok.Data;

@Data
public class Stage {


    private int idStage;
    private String nomStage;

}
