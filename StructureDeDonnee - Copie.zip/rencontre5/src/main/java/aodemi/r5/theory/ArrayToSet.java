package aodemi.r5.theory;

import java.util.*;

public class ArrayToSet {

    public static void main(String[] args) {

        Integer[] tableau= {1, 2, 3};

        // 1ère Façon
        Set<Integer> set= new HashSet<>();
        Collections.addAll(set, tableau);
        System.out.println(set);


        //2ème Façon
        Collection <Integer> set2= new HashSet<>();
        Collections.addAll(set2, tableau);
        System.out.println(set2);

        //3ème Façon  ***
        //TreeSet trie par défaut
        Set<Integer> set3 = new TreeSet<>( Arrays.asList(1,2,3,4,5,6,7,8,9));
        System.out.println(set3);

        // Polymorphisme = on declare une classe a partir de son parent ou à partir de son interface.
        // TreeSet hérite de Set.

        // 4ème Façon
        TreeSet<Integer> set4 = new TreeSet<>();
        for(int i=0; i<tableau.length; i++){
            set4.add(tableau[i]);
        }
        System.out.println(set4);
    }
}
