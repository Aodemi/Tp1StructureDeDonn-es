package aodemi;

public class Etudiant {
    public int id;
    public String nom;

    public Etudiant(int id, String nom) {
        this.id = id;
        this.nom = nom;
    }

    public String toString() {
        return (this.id + " | " + this.nom);
    }
}
