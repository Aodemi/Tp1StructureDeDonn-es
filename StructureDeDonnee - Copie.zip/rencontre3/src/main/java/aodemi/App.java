package aodemi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

public class App
{
    public static void main( String[] args ) {
        int [] tableau = {3, 6, 1, 8, 2, 9, 4};
        String [] tableau2 = {"H", "D", "A", "E"};
        int a = 1;

        for (int i : tableau) {
            a=i;
        }

        ArrayList<Integer> listeInt = new ArrayList();
        listeInt.add(3); listeInt.add(2); listeInt.add(1);

        ArrayList<String> listeString = new ArrayList();
        listeString.add("Lundi"); listeString.add("Mardi"); listeString.add("Mercredi");

        Collections.sort(listeInt);



        ArrayList<Etudiant> listeEtudiant = new ArrayList(Arrays.asList(
                new Etudiant(1, "Donnie"),
                new Etudiant(2, "John"),
                new Etudiant(3, "Francis")
        ));

        HashSet set = new HashSet();
        set.add(100);
        set.add(100);
        set.add(100);
        System.out.println(set);

        for(Etudiant etudiant : listeEtudiant) {
            System.out.println(etudiant);
        }
    }
}
