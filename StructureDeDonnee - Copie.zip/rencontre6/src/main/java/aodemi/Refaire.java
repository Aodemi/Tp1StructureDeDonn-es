package aodemi;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class Refaire {
    /*
*     public static List<Etudiant> jsonToEtudiant(String path) throws Exception {
        return new ObjectMapper().readValue(new FileInputStream(path), new TypeReference<List<Etudiant>>(){});
    }*/

    /*
        public static boolean saveListeStagesToJson(List<Stage> stages, String path, String departement) throws Exception{
        List<Stage> tempList = new ArrayList<>();
        for(Stage stage : stages){
            if(stage.getDepartement().equals(departement)){tempList.add(stage);}
        }
        new ObjectMapper().writeValue(new FileOutputStream(path), stages);
        return new File(path).exists() && new File(path).length() > 0;
    }
     */

    /*
        public static boolean saveListeStagiairesToJson(List<Etudiant> stagiaires, String path, String departement) throws Exception{
        List<Etudiant> tempList = new ArrayList<>();
        for(Etudiant stagiaire : stagiaires){
            if(stagiaire.getDepartement().equals(departement)){tempList.add(stagiaire);}
        }
        new ObjectMapper().writeValue(new FileOutputStream(path), stagiaires);
        return new File(path).exists() && new File(path).length() > 0;
    }
     */

    public static boolean saveListProduitToJson(List<Produit> produitList, String path) throws Exception {
        new ObjectMapper().writeValue(new FileOutputStream(path), produitList);
        return new File(path).exists() && new File(path).length() > 0;
    }
    public static List<Produit> repeter(String path) throws Exception{
        return new ObjectMapper().readValue(new FileInputStream(path), new TypeReference<List<Produit>>(){});
    }
}
