package aodemi;

import java.util.List;

public class Produit {
    private int id;
    private String nom;
    private double prix;
    private String departement;
    private List<String> produits;
}
