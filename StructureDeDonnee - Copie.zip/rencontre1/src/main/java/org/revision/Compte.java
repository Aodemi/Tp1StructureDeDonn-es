package org.revision;

public class Compte {
    private int idCompte;
    public String nomCompte;
    protected double soldeCompte;

    public Compte(int idCompte, String nomCompte, double soldeCompte) {
        this.idCompte = idCompte;
        this.nomCompte = nomCompte;
        this.soldeCompte = soldeCompte;
    }

    public int getIdCompte() {
        return idCompte;
    }

    private String getNomCompte() {
        return nomCompte;
    }

    protected double getSoldeCompte() {
        return soldeCompte;
    }
}
