package org.revision;

public class Test {
    public static void main(String[] args) {
        Compte compte1 = new Compte(1, "Compte1", 120);
        System.out.println("Bonjour " + compte1.getIdCompte());
    }
}
