package org.example.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.entity.Compte;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

public class Services {

    public static void addCompteToCollection(Collection<Compte> tableau, Compte compte) throws Exception {
        tableau.add(compte);
    }
    public static void deleteCompteToCollection(Collection<Compte> tableau, Compte compte) throws Exception {
        tableau.remove(compte);
    }
    public static String findCompteFromCollection(Collection<Compte> tableau, Compte compte) throws Exception {
        for (Compte c : tableau) {
            if (c.equals(compte)) {
                return c.toString();
            }
        }
        return "Aucun compte ne correspond.";
    }
    public static void emptyCollection(Collection<Compte> tableau) {
        tableau.clear();
    }

    public static void createJsonFile(Collection<Compte> tableau, String path) throws Exception {
        new ObjectMapper().writeValue(new FileOutputStream(path), tableau);
    }


    public void addCompteToList(Compte compte, List<Compte> liste) {
        liste.add(compte);
    }
    public String findCompteInList(int id, List<Compte> liste) {
        for(Compte compte : liste){
            if (id == compte.getIdCpte()){
                return compte.toString();
            }
        }
        return "Aucun compte correspondant.";
    }
    public void deleteCompteFromList(int id, List<Compte> liste) {
        for(Compte compte : liste){
            if (id == compte.getIdCpte()){
                liste.remove(compte);
                System.out.println("Le compte à bien été retiré.");
                break;
            }
        }
        System.out.println("Aucun compte correspondant.");
    }
    public void emptyList(List<Compte> liste) {
        liste.clear();
    }
    public void sortList(List<Compte> liste) {
        Arrays.sort(liste.toArray());
    }
}
