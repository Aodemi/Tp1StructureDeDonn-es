package org.example.service;

import org.example.entity.Compte;

import java.util.List;
import java.util.ArrayList;


public class TestServices {
    public static void main(String[] args) throws Exception {
        List<Compte> liste = new ArrayList<>();
        Compte c1 = new Compte("Toto", "Tata", 200);
        Compte c2 = new Compte("Dodo", "Dada", 1000);

        Services.addCompteToCollection(liste, c1);
        Services.addCompteToCollection(liste, c1);
        Services.addCompteToCollection(liste, c2);

        Services.createJsonFile(liste, "C:\\Users\\2258849\\OneDrive - Cégep Marie-Victorin\\Desktop\\StructureDeDonnee\\rencontre4\\data\\toto.json");


    }
}
