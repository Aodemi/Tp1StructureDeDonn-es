package org.example;

import org.example.entity.Compte;

public class App
{
    public static void main( String[] args ){
        Compte test1 = new Compte("Mattis", "Beaupré", 5);
        Compte test2 = new Compte("Mundo", "Beauté", 5);
        Compte test3 = new Compte("Malto", "Beaufrais", 5);
        Compte test4 = new Compte("Merlin", "Beauplat", 5);

        System.out.println(test1.getIdCpte() + "\n" + test2.getIdCpte() + "\n" + test3.getIdCpte() + "\n" + test4.getIdCpte());
    }
}
