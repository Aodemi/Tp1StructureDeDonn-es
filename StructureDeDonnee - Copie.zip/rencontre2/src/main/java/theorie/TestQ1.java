package theorie;

public class TestQ1 {
    public static void main(String[] args) {
        // Q1 instance = new Q1

        Personne alain = new Personne();
        Personne bob = new Personne();
    }
}
