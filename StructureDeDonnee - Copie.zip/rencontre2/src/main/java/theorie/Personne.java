package theorie;

public class Personne {

    private int age;

    public String quiSuisJe (String prenom){
        return prenom;
    };
}
