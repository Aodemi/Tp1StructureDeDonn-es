package theorie;

public class Etudiant extends Personne {

}
