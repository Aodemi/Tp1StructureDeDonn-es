package theorie;

public interface Q1 {

}
