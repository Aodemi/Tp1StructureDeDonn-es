package org.example;

public class Exo1 {

    String chaine;

    public Exo1(String chaine) {
        this.chaine = chaine;
    }

    public String lowerToMaj(){
        return chaine.toLowerCase();
    }

    public String majToLower(){
        return chaine.toUpperCase();
    }

    public String noSpecialChar(){
        return chaine.replaceAll("[^a-zA-Z]", "");
    }
}
