package org.example;
import org.example.Exo1;

public class App 
{
    public static void main( String[] args ) {

        Exo1 chaine = new Exo1("A-b-C-d-E-f-1234-***///->");

        System.out.println(chaine.majToLower());
        System.out.println(chaine.lowerToMaj());
        System.out.println(chaine.noSpecialChar());

        Exo2 semaine = new Exo2();

        System.out.println(semaine.jourAleatoire());
        System.out.println(semaine.joursTries());
    }
}
