package org.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Exo2 {

    String [] days = {"Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"};

    public String jourAleatoire(){
        return days[(int)(Math.random() * days.length)];
    }

    public List<String> joursTries(){
        List<String> joursTries = Arrays.asList(days);
        Collections.sort(joursTries);
        return joursTries;
    }
}
