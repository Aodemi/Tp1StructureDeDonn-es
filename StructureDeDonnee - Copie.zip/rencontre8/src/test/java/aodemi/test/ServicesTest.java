package aodemi.test;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ServicesTest {

    @Test
    public void testSortByPrice() {
        assertFalse(5+5 == 100);
    }

    @Disabled
    @Test
    public void testSortById() {
    }
}