package aodemi.utils;

public class Reflexion {
}
