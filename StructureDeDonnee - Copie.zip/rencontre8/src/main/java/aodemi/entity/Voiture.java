package aodemi.entity;

import lombok.Data;
import java.util.*;


@Data
public class Voiture implements Comparable<Voiture>{

    private int idVoiture;
    private String marque;
    private boolean hybride;
    private double prix;

    private Personne proprietaire;

    @Override
    public int compareTo(Voiture voiture) {
        return Integer.compare(this.getIdVoiture(), voiture.getIdVoiture());
    }
}
