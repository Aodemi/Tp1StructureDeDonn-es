package aodemi.entity;

import java.util.Comparator;

public class VoitureMarqueComparator implements Comparator<Voiture> {
    @Override
    public int compare(Voiture v1, Voiture v2) {
        return v1.getMarque().compareToIgnoreCase(v2.getMarque());
    }
}
