package aodemi.entity;

import java.util.Comparator;

public class VoiturePrixComparator implements Comparator<Voiture> {
    @Override
    public int compare(Voiture v1, Voiture v2) {
        return Double.compare(v1.getPrix(), v2.getPrix());
    }
}
