package aodemi.entity;

import java.util.Comparator;

public class VoitureHybrideComparator implements Comparator<Voiture> {
    @Override
    public int compare(Voiture v1, Voiture v2) {
        return Boolean.compare(v1.isHybride(), v2.isHybride());
    }
}
