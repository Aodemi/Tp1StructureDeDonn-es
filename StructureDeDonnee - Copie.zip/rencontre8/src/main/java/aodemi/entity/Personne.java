package aodemi.entity;

import lombok.Data;

import java.util.*;

@Data
public class Personne implements Comparable<Personne>{

    private int idPersonne;
    private String nom;
    private List<Voiture> voitures;

    @Override
    public int compareTo(Personne personne) {
        return Integer.compare(this.getIdPersonne(), personne.getIdPersonne());
    }

    enum PersonneComparator{
        NAME, ID
    }
}
