package aodemi.service;

import aodemi.entity.Voiture;
import aodemi.entity.VoiturePrixComparator;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Services {

    public static List<Voiture> sortByPrice(List<Voiture> voitures) throws Exception{
        Collections.sort(voitures, new VoiturePrixComparator());
        return voitures;
    };
    public static List<Voiture> sortById(List<Voiture> voitures) throws Exception{
        Collections.sort(voitures);
        return voitures;
    };
}
