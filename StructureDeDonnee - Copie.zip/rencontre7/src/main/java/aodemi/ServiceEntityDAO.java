package aodemi;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;


import java.io.File;
import java.io.FileInputStream;
import java.util.*;

public class ServiceEntityDAO {//DAO => Data Access Object
    public static List<Entity> readData(String path) throws Exception {
        List<Entity> retour = new ArrayList<>();
        retour = new ObjectMapper().readValue(new FileInputStream(path), new TypeReference<List<Entity>>(){

        });
        return retour;
    }

    public static List<Entity> sortListByChoix(String path, String choix) throws Exception {
        List<Entity> sortedList = readData(path);

        if(choix.equals("fname")) {
            Collections.sort(sortedList, new Comparator<Entity>() {
                @Override
                public int compare(Entity o1, Entity o2) {
                    return o1.getFname().compareToIgnoreCase(o2.getFname());
                }
            });
        } else if(choix.equals("avantage")) {

        }
        else{
            sortedList = null;
        }
        return sortedList;
    }

    public static void main(String[] args){
        try{
            List<Entity> ll = readData("rencontre7/data/examen.json");
            System.out.println(ll);
            Collections.sort(ll);
            System.out.println(ll);
//            System.out.println(readData("rencontre7/data/examen.json"));
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
