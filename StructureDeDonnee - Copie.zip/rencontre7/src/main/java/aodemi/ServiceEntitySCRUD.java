package aodemi;

public class ServiceEntitySCRUD {// SCRUD => Search Create Read Update Delete
}
