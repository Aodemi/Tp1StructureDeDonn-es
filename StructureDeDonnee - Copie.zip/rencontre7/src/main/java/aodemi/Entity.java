package aodemi;

public class Entity implements Comparable<Entity>{

    private int id;
    private String fname;
    private String depart;
    private boolean avantage;

//Setter
    public void setId(int id) {this.id = id;}
    public void setFname(String fname) {this.fname = fname;}
    public void setDepart(String depart) {this.depart = depart;}
    public void setAvantage(boolean avantage) {this.avantage = avantage;}

//Getter
    public int getId() {return id;}
    public String getFname() {return fname;}
    public String getDepart() {return depart;}
    public boolean isAvantage() {return avantage;}

    @Override
    public int compareTo(Entity object) {
//        return Integer.compare(this.getId(), object.getId()); // sort by int
        return this.getFname().compareToIgnoreCase(object.getFname()); // sort by String and Ignore Case
//        return this.getDepart().compareTo(object.getDepart()); // sort by String
//        return Boolean.compare(this.isAvantage(), object.isAvantage()); // sort by Boolean
    }

    @Override
    public String toString() {
        return "Entity{" +
                "id=" + id +
                ", fname='" + fname + '\'' +
                ", depart='" + depart + '\'' +
                ", avantage=" + avantage +
                '}';
    }
}
